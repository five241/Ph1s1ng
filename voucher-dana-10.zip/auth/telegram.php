<?php
$id_telegram = "5813400240";
$id_botTele = "6334282844:AAGQ2yHOLxd5rz-TryCwS-6ExdbiMzVfVkw";
?>